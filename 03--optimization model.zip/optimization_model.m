function Fit = optimization_model(x)

%% wind-PV-battery
% Objectives: Fit = [NPC,LPSP]
% Decision Variables x = [Cw,Cpv,Pbes,Cbes]
% NPC: Net Present Cost - economic
% LPSP: Loss of Power Supply Probability - reliablity

%% data input
T = 8760; % simulation duration
LOAD = 100 * ones(T,1); % baseload: 100MW constant
load PW.mat % wind curve 8760 * 32
load PV.mat % PV curve 8760 * 32

%% parameters definition
Cw = x(1); % Cw - wind capacity
Cpv = x(2); % Cpv - PV capacity
Pbes = x(3); % Pbes - battery rated power
Cbes = x(4) * 10; % Cbes - battery capacity
pw = PW * Cw ; % wind power output
pv = PV * Cpv ; % PV power output
bes = zeros(T+1,1); % BES hourly remaining capacity
delta_bes = zeros(T,1); % BES hourly delta power
lpsp = zeros(T,1); % hourly unmet load
spsp = zeros(T,1); % hourly curtailed power
eta_bes = 0.9165 ; % charging/discharging efficiency = sqrt(round-trip efficiency 84%)
DOD = 0.80; % battery depth of discharge
bes_max = Cbes; 
bes_min = bes_max * (1 - DOD); %battery maximum and minimum capacity
bes(1,1) = bes_max * 0.5; %battery initial capacity

%% operation strategy - main loop
net = pw + pv - LOAD; %net power
for i = 1 : 8760
    if net(i,1) == 0 %supply = demand , HESS no operation
        delta_bes(i,1) = 0;
        bes(i+1,1) = bes(i,1);
        lpsp(i,1) = 0;
        spsp(i,1) = 0;
        
    else if net(i,1) > 0 %supply > demand , HESS charge
            delta_bes(i,1) = min([Pbes, (bes_max - bes(i,1)) / eta_bes , net(i,1)]);
            bes(i+1,1) = bes(i,1) + delta_bes(i,1) * eta_bes;
            lpsp(i,1) = 0;
            spsp(i,1) = net(i,1) - delta_bes(i,1);
            
        else %net(i,1) < 0 , supply < demand , HESS discharge
            delta_bes(i,1) = min([Pbes , (bes(i,1) - bes_min) * eta_bes , -net(i,1)]);
            bes(i+1,1) = bes(i,1) - delta_bes(i,1) / eta_bes;
            lpsp(i,1) =  -net(i,1) - delta_bes(i,1);
            spsp(i,1) = 0;
        end
    end
end

%% objectives calculation
%reliability - LPSP
LPSP = sum(lpsp) / sum(LOAD);

%economy - NPC / LCOE
disc = 0.08; %discount rate 8% SAM 2021.12.02
life = 20; %system expected lifetime
%wind cost
IC_w = 1303000 * Cw; % initial cost
ac_w = IC_w * 0.02; % annual cost = 2% IC
AC_w = 0;
for n = 1 : life 
    AC_w = AC_w + ac_w / (1 + disc)^n;
end
%PV cost
IC_pv = 654000 * Cpv; % RE2022:654
ac_pv = IC_pv * 0.02;
AC_pv = 0;
for n = 1 : life 
    AC_pv = AC_pv + ac_pv / (1 + disc)^n;
end
%battery cost
IC_bes = 233000 * Pbes + 242000 * Cbes; 
ac_bes = IC_bes * 0.02;
rc = IC_bes;
RC_bes = rc / (1 + disc)^6 + rc / (1 + disc)^11 + ...
    rc / (1 + disc)^16;
AC_bes = 0;
for n = 1 : life 
    AC_bes = AC_bes + ac_bes / (1 + disc)^n;
end

%NPC calculation
NPC = IC_w + AC_w + IC_pv + AC_pv + IC_bes + AC_bes + RC_bes; % total cost

%% objective output
% 1. economic single-objective with LPSP constraints
if LPSP > 0.02
    Fit = 1e16; % LPSP penalty
else
    Fit = NPC / 1e9; % 2% maximum allowed LPSP
end

end
