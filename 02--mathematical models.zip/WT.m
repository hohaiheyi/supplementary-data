function output = WT(input , u1 , u2 , u3 , u4)

% wind turbine parameters setting
T = 8760; % time duration
ws = input; % wind speed
Vci = u1; % cut-in wind speed
Vco = u2; % cut-off wind speed
Vr = u3; % rated wind speed
Pwr = u4; % rated power of wind turbine
pw = zeros(T,1); % wind power

% wind power calculation
for i = 1 : T
    if ws(i,1) < Vci || ws(i,1) > Vco % unavailable
        pw(i,1) = 0;
    else if ws(i,1) >= Vr % rated operation
            pw(i,1) = Pwr;
        else % linear interpolation
            pw(i,1) = Pwr * (ws(i,1)^3 - Vci^3) / (Vr^3 - Vci^3);
        end
    end
end

output = pw; % wind power output
end