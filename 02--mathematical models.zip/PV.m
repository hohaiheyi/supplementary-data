function output = PV(input1 , input2 , u1 , u2 , u3 , u4 , u5 , u6 , u7)

% PV parameters setting
T = 8760; % time duration
GHI = input1; % global horizontal irradiance
Temp = input2; % ambient temperature
Istc = u1; % standard test condition irradiance
Iref = u2; % reference irradiance
NOCT = u3; % nominal operation cell temperature
Tstc = u4; % STC temperature
Tref = u5; % reference temperature
beta = u6; % temperature factor
Ppvr = u7; % rated power of PV panel
Tpv = zeros(T,1); % operation temperature
pv = zeros(T,1); % PV power 

% PV power calculation
for i = 1 : T
    Tpv(i,1) = Temp(i,1)  + (NOCT - Tref) * GHI(i,1) / Iref;
    pv(i,1) = Ppvr * GHI(i,1) / Istc * ( 1 - beta * (Tpv(i,1) - Tstc) );
end

output = pv; % PV power output
end